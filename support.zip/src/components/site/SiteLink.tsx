import { Link } from "@tanstack/react-router";
import type { ComponentProps } from "react";

const LOCAL_PAGES = {
  "https://uniplusoverseas.com/about/": "/about",
  "https://uniplusoverseas.com/services/": "/services",
  "https://uniplusoverseas.com/blog/": "/blog",
} as const;

export function SiteLink({ href, children, ...props }: ComponentProps<"a">) {
  const destination = href && Object.entries(LOCAL_PAGES).find(([source]) => source === href)?.[1];
  if (destination) return <Link to={destination} {...props}>{children}</Link>;
  return <a href={href} {...props}>{children}</a>;
}