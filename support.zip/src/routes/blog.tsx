import { createFileRoute } from "@tanstack/react-router";
import { ArrowUpRight, ImageIcon } from "lucide-react";
import { InnerPage, PageSection, Reveal } from "@/components/site/InnerPage";
import content from "@/lib/inner-page-content.json";
import { getAsset, bannerPhoto } from "@/lib/site-content";

const title = content.blog.blocks[0].text;
const description = content.blog.posts[0]?.title ?? title;
export const Route = createFileRoute("/blog")({
  head: () => ({
    meta: [
      { title: `${title} | Uniplus Overseas` }, { name: "description", content: description },
      { property: "og:title", content: `${title} | Uniplus Overseas` }, { property: "og:description", content: description },
      { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
    ]
  }),
  component: BlogPage,
});

function BlogPage() {
  return <InnerPage title={title} image={bannerPhoto}>
    <PageSection>
      <div className="grid gap-x-6 gap-y-9 md:grid-cols-2 lg:grid-cols-3">
        {content.blog.posts.map((post, index) => {
          // post 1 -> src/assets/inner-blog-1.*, post 2 -> inner-blog-2.* ...
          const image = getAsset(post.image);
          return <Reveal as="article" key={post.href} delay={(index % 3) * 70} className="inner-post flex flex-col overflow-hidden rounded-md border border-border bg-card">
            <a href={post.href} aria-label={post.title} className="block aspect-video overflow-hidden bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
              {image ? <img src={image} alt={post.title} loading="lazy" className="inner-post-image h-full w-full object-cover" /> : <div className="flex h-full items-center justify-center text-muted-foreground"><ImageIcon className="h-10 w-10" strokeWidth={1} aria-hidden="true" /></div>}
            </a>
            <div className="flex flex-1 flex-col p-6 sm:p-7">
              <p className="mb-4 text-xs font-medium text-muted-foreground">{post.date}</p>
              <h2 className="text-xl font-bold leading-snug text-navy"><a href={post.href} className="transition-colors hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">{post.title}</a></h2>
              {post.excerpt && <p className="mt-4 text-sm leading-7 text-muted-foreground">{post.excerpt}</p>}
              <div className="mt-auto pt-7"><a href={post.href} className="inline-flex min-h-11 items-center gap-3 text-sm font-semibold text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">{post.readLabel}<ArrowUpRight className="h-4 w-4" aria-hidden="true" /></a></div>
            </div>
          </Reveal>
        })}
      </div>
    </PageSection>
  </InnerPage>;
}